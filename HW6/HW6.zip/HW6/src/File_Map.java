import java.util.*;

public class File_Map implements Map
{

    ArrayList<String> fnames;
    ArrayList<List<Integer>> occurances;

    @Override
    public String toString() {
        String temp = "";

        for (int i = 0;i<fnames.size();i++ ){
            temp += "File_Map{" +
                    "fnames=" + fnames.get(i) +
                    ", occurances=" + occurances.get(i) +
                    '}' + "             \n";
        }
        return temp;
    }



    public File_Map(String fname,Integer occurance){
        fnames = new ArrayList<String>(100);
        List <Integer> oneList = new ArrayList<>(100);
        occurances = new ArrayList<>(100);
        oneList.add(occurance);
        fnames.add(fname);
        occurances.add(oneList);
    }


    @Override
    /*Each put operation will extend the occurance list*/
    // filenames and occurance


    public Object put(Object key, Object value) {

        key = (ArrayList) key;
        value = (ArrayList)value;
        int i = 0;
        boolean flag = true;
        List a = (List) ((ArrayList) value).get(0);
        Integer b = (Integer) a.get(0);

        try {
            while (fnames.get(i) != null && !fnames.get(i).equals((String) ((ArrayList) key).get(0))) {
                i++;
            }

        }catch (Exception e){

            fnames.add((String) ((ArrayList) key).get(0));
            List <Integer> oneList = new ArrayList<>(50);
            occurances.add(oneList);
            occurances.get(i).add(b);
            flag = false;
        }
        if (flag&&fnames.get(i) == null){
            fnames.add((String) ((ArrayList) key).get(0));
            List <Integer> oneList = new ArrayList<>(50);
            occurances.add(oneList);
            occurances.get(i).add(b);


        }else if(flag) {
             try {

                 occurances.get(i).add(b);
             }catch (Exception e){

                 System.out.println(occurances.get(i));
             }

        }
        return key;
    }



    @Override
    public int size() {
        return fnames.size();
    }

    @Override
    public boolean isEmpty() {
        return (fnames.size() == 0);
    }

    @Override
    public boolean containsKey(Object key) {

        for (int i = 0;i<fnames.size();i++){
            if (fnames.get(i) == key){
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean containsValue(Object value) {

        for (int i = 0;i<occurances.size();i++){
            if (occurances.get(i).equals(value) ){
                return true;
            }
        }
        return false;
    }

    @Override
    public Object get(Object key) {

        int i = 0;
        while (fnames.get(i) != null && !fnames.get(i).equals((String) ((ArrayList) key).get(0))) {
            i++;
        }
        return occurances.get(i);

    }

    @Override
    public void putAll(Map m) {
        int s = m.size();
        m =(File_Map)m;
        if (s > 0) {
            for (int i=0;i<m.size();i++){
             fnames.add (((File_Map) m).fnames.get(i));
             occurances.add(((File_Map) m).occurances.get(i));
            }
        }
    }

    @Override
    public void clear() {
        fnames = new ArrayList<String>(100);
        List <Integer> oneList = new ArrayList<>(100);
        occurances = new ArrayList<>(100);
        occurances.add(oneList);
    }

    @Override
    public Set keySet() {
        HashSet keys = new HashSet<>();
        for (int i = 0; i < fnames.size(); i++) {
            if (fnames.get(i) != null)
                keys.add(fnames.get(i));
        }
        return keys;
    }

    @Override
    public Collection values() {
        ArrayList values = new ArrayList<>();
        for (int i = 0; i < occurances.size(); i++) {
            if (occurances.get(i) != null)
                values.add(occurances.get(i));
        }
        return values;
    }

    @Override
    /*You do not need to implement entrySet function
     * */
    public Set<Entry> entrySet() {
        return null;
    }

    @Override
    /*You do not need to implement remove function
     * */
    public Object remove(Object key) {
        return null;
    }
}

