import java.util.*;

public class Word_Map implements Map, Iterable
{

    final static int INITCAP=10;  //initial capacity
    private double LOAD_THRESHOLD = 0.75;
    int CURRCAP = INITCAP;   //current capacity
    private Node table[];
    private int size;
    private int PRIME = 7;


    private  Node temp=null;
    private  Node FIRST = null;
    private String tempBigKey = null;
    private String tempBigFile = null;

    int bigNextTextFile = 0;

    @Override
    public Iterator<Node> iterator() {

        Iterator<Node> iterator = new Iterator<Node>() {
            private Node temp2 = null; // Reference variable to a temporary node.
            private Node current = FIRST;
            @Override
            public boolean hasNext() { // True if there is a next Object .
                if(current == null) {
                    return false;
                }
                else {
                    return true;
                }
            }
            @Override
            public Node next() { // Return the object.
                if (!hasNext()) {
                    throw new java.util.NoSuchElementException();
                }
                temp2 = current;
                current = current.nextWord;
                return temp2;
            }
        };
        return iterator; // Return an iterator that has just been called.
    }

    static class Node {
        public Node nextWord = null;
        public File_Map keywordFiles;
        private String key = null;

        public  ArrayList<String> bigramsWords = new ArrayList<String>();

        @Override
        public String toString() {
            return key + "\n"  + keywordFiles;
        }

        public Node(Object key, Object value){
            this.key = (String)key;
            this.keywordFiles = (File_Map) value;

        }

        public String getKey() {
            return key;
        }

        public File_Map getValue() {
            return keywordFiles;
        }

        public File_Map setValue(File_Map setFile) {
            File_Map oldValue = keywordFiles;
            keywordFiles = setFile;
            return oldValue;
        }
        public void putValue(File_Map setFile) {
            keywordFiles.put(setFile.fnames,setFile.occurances);
        }

    }


    @Override
    public int size() {
        return table.length;
    }
    public Word_Map() {
        this.table = new Node[INITCAP*1000];
        this.size = 0;
    }

    @Override
    public boolean isEmpty() {

        return (this.size == 0);
    }

    @Override
    public Object get(Object key) {
        return table[find(key)];
    }

    @Override
    public Object put(Object key, Object value) {

        File_Map oldValue = null;

        double currentRate = size/CURRCAP;

        if (currentRate>LOAD_THRESHOLD) {
            rehash();
        }
        int index = find(key);

        if (table[index] == null) {

            table[index] = new Node(key,value);


            if (size==0){
                FIRST = table[index];
            }
            if (size == 1 ){
                FIRST.nextWord = table[index];
                temp = FIRST.nextWord;
            }
            if (size != 0 && size != 1) {
                temp.nextWord = table[index];
                temp = table[index];
            }
            size++;


        }else if (key.equals(table[index].key)){
            table[index].putValue((File_Map) value);
        }else {
            oldValue = table[index].getValue();
            table[index].setValue((File_Map) value);
        }
        String filename = ((File_Map) value).fnames.get(0);
        bigramsFunction(key,filename);

        return oldValue;
    }

    @Override
    public boolean containsKey(Object key) {

        Iterator iterator = iterator();

        while(iterator.hasNext()) {
            Node e = (Node) iterator.next();
            if (e.getKey().equals(key)){
                return true;
            }
        }
        return false;
    }


    @Override
    public void putAll(Map m) {
        int s = m.size();
        if (s > 0) {
            size = size + s;
            if (( CURRCAP/size) > this.LOAD_THRESHOLD){
                this.rehash();
            }
            Iterator iterator = m.entrySet().iterator();

            while(iterator.hasNext()) {
                Node e = (Node) iterator.next();
                String key = e.getKey();
                File_Map value = e.getValue();
                this.put(key, value);
            }
        }
    }

    @Override
    public void clear() {
        PRIME = 7;
        this.table = new Node[INITCAP];
        this.size = 0;
    }

    @Override
    public boolean containsValue(Object value) {

        Iterator iterator = iterator();

        while(iterator.hasNext()) {
            Node e = (Node) iterator.next();
            if (e.getValue().equals(value)){
                return true;
            }
        }

        return false;
    }

    @Override
    public Set keySet() {
        HashSet keys = new HashSet<>();
        Iterator iterator = iterator();

        while(iterator.hasNext()) {
            Node e = (Node) iterator.next();
            keys.add(e.getKey());
        }
        return keys;
    }

    @Override

    public Collection values() {
        ArrayList values = new ArrayList<>();
        for (int i = 0; i < table.length; i++) {
            if (table[i] != null)
                values.add(table[i].getValue());
        }
        return values;
    }


    private int find(Object key) {

        int index = hashCode1(key);
        while (index < 0)
            index += table.length;
        while ((table[index] != null)
                && (!key.equals(table[index].getKey()))) {
                index++;
            if (index == table.length)
                index=0;

        }
        return index;
    }

    private void bigramsFunction(Object key,String filename){

        if (bigNextTextFile == 0) {
            tempBigFile = filename;
            tempBigKey = (String) key;
            bigNextTextFile++;
        }else if (tempBigFile!=null&&tempBigFile.equals(filename)){
            (table[find(tempBigKey)]).bigramsWords.add((String) key);
            bigNextTextFile++;
            tempBigFile = filename;
            tempBigKey = (String) key;
        }else{
            tempBigFile = filename;
            tempBigKey = (String) key;
            bigNextTextFile = 1;
        }
    }

    private int hashCode1(Object key) {
        return key.hashCode() % table.length;
    }

    private void rehash() {
        bigNextTextFile = 0;
        tempBigKey = null;
        tempBigFile = null;

        Node [] oldTable = table;
        CURRCAP = 2*oldTable.length + 1;
        table = new Node[2*oldTable.length + 1];
        size = 0;
        for (int i = 0; i < oldTable.length; i++) {
            if (oldTable[i] != null)
                put(oldTable[i].getKey(), oldTable[i].getValue());
        }
        for (int i = table.length-1; i > 1; i++) {
            if (isPrime(i)) {
                PRIME = i;
                break;
            }
        }
    }
    private boolean isPrime(int number) {
        for (int i = 2; i < number; i++)
            if (number % i == 0)
                return false;
        return true;
    }

    @Override
    public String toString() {
        String tablePresent = "";
        for (int i = 0; i<table.length;i++){
             if (table[i] != null) {
                 tablePresent += i + " " + table[i];
                 tablePresent += "\n";
             }
        }
        return tablePresent;
    }


    @Override
    /*You do not need to implement entrySet function
     * */
    public Set<Entry> entrySet() {
        throw new UnsupportedOperationException("putAll method is not supported for this map.");
    }

    @Override
    /*You do not need to implement remove function
     * */
    public Object remove(Object key) {
        throw new UnsupportedOperationException("putAll method is not supported for this map.");
    }

}
