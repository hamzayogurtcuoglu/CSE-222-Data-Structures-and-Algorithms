import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        NLP nlp = new NLP();
        nlp.readDataset("dataset/");

        nlp.printWordMap();

        System.out.println("--------------START INFUT FILE --------------");

        Scanner sc2 = null;
        try {
            sc2 = new Scanner(new File("src/input"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try{
            while (sc2.hasNextLine()) {
                Scanner s2 = new Scanner(sc2.nextLine());
                String queryType = null;
                String word = null;
                String filename = null;
                int index = 0;
                while (s2.hasNext()) {
                    String s = s2.next();
                    s = s.replaceAll(" ", "");
                    s = s.replaceAll("\n", "");
                    if (s.length() != 0) {
                        if (index == 0)
                            queryType = s;
                        if (index == 1)
                            word = s;
                        if (index == 2)
                            filename = s;

                        if (index == 1 && queryType.equals("bigram")) {

                            System.out.println("\n " + nlp.bigrams(word));
                        }

                        if (index == 2 && queryType.equals("tfidf")) {
                            System.out.println("\n " + nlp.tfIDF(word, filename));
                        }
                        index++;
                    }
                    s = "";
                }
            }
        }catch (NullPointerException e){
            System.out.println("There is no type or word, Change! inputFile ");
        }
        System.out.println("--------------END INFUT FILE --------------");

    }
}
