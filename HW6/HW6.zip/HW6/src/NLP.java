import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class NLP
{
    public Word_Map wmap;

    public Word_Map keywordMap = new Word_Map();
    float documentNumber = 0;
    String documentName = null;
    /*Reads the dataset from the given dir and created a word map */
    public void readDataset(String dir)
    {
        documentName = dir;
        File directory = new File(dir);
        Scanner sc2 = null;
        int index = 0;
        try {
            for (File file : directory.listFiles()) {
                documentNumber++;
                try {
                    sc2 = new Scanner(file);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                int occurance = 0;
                while (sc2.hasNextLine()) {
                    Scanner s2 = new Scanner(sc2.nextLine());
                    while (s2.hasNext()) {

                        String s = s2.next();
                        s = s.replaceAll("[\\-\\+\\.\\^\\\":,()<>?!&%}{']", "");
                        s = s.replaceAll(" ","");
                        if (s.length() != 0 ) {
                            File_Map file_map = new File_Map(file.getName(), occurance);
                            keywordMap.put(s, file_map);

                            occurance++;
                            index++;
                        }
                    }
                }
            }
        }catch (NullPointerException e){
            System.out.println(e);
        }
    }


    /*Finds all the bigrams starting with the given word*/
    public List<String> bigrams(String word){
        Set<String> bigramList = new HashSet<>();
        int size = ((Word_Map.Node)keywordMap.get(word)).bigramsWords.size();
        for (int i = 0;i<size;i++){
            String otherword = ((Word_Map.Node)keywordMap.get(word)).bigramsWords.get(i);
            String bigram = word + " " + otherword;
            bigramList.add(bigram);
        }
        List<String> bigramList2 = new ArrayList<>();
        for (String s : bigramList){
            bigramList2.add(s);
        }
        return bigramList2;
    }


    /*Calculates the tfIDF value of the given word for the given file */
    public float tfIDF(String word, String fileName)
    {   Scanner sc2 = null;
        try {
            sc2 = new Scanner(new File(documentName+"/"+fileName));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        float documentTermNumber = 0;
        while (sc2.hasNextLine()) {
            Scanner s2 = new Scanner(sc2.nextLine());
            while (s2.hasNext()) {
                String s = s2.next();
                s = s.replaceAll("[\\-\\+\\.\\^\\\":,()<>?!&%}{']", "");
                s = s.replaceAll(" ","");
                if (s.length() != 0 ) {
                    documentTermNumber++;
                }
            }
        }
        float numberOfDocumentwithTerm = ((Word_Map.Node)keywordMap.get(word)).getValue().fnames.size();
        float numberOfWord = 0;
        int i = 0;
        for (;numberOfDocumentwithTerm>i;i++ ){
            if (((Word_Map.Node)keywordMap.get(word)).getValue().fnames.get(i).equals(fileName)){
                break;
            }
        }
        numberOfWord = ((Word_Map.Node)keywordMap.get(word)).getValue().occurances.get(i).size();

        float TF = numberOfWord / documentTermNumber;
        float IDF = (float) Math.log(documentNumber/numberOfDocumentwithTerm);
        return (TF*IDF);
    }

    /*Print the WordMap by using its iterator*/
    public  void printWordMap()
    {
        Iterator iterator = keywordMap.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }
    }

}
